<?php

$msg = $_GET["msg"];
echo $msg;

?>
